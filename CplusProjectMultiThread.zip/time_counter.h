//////////////////////////////////////////////////////////////////////////////////
class time_passed_counter
{
public:
    time_passed_counter(void)
    {
        m_start_ts_sec  = 0;
        m_start_ts_usec = 0;
    };

    ~time_passed_counter(void)
    {
    };

    void initialize()
    {
#ifdef _WIN32
        typedef union
        {
            unsigned __int64 ft_scalar;
            FILETIME ft_struct;
        } FT;

        FT nt_time;
        GetSystemTimeAsFileTime(&(nt_time.ft_struct));
        unsigned __int64 usec = (nt_time.ft_scalar - 116444736000000000i64) / 10i64;
        unsigned long ts_sec  = (unsigned long) (usec / 1000000);
        unsigned long ts_usec = (unsigned long) (usec % 1000000);
#else
        timeval tv;
        gettimeofday(&tv,NULL);
        unsigned long ts_sec = tv.tv_sec;
        unsigned long ts_usec = tv.tv_usec;
#endif

        m_start_ts_sec  = ts_sec;
        m_start_ts_usec = ts_usec;
    }

    unsigned long get_diff() // return difference in milliseconds (from init time)
    {
        if ((m_start_ts_sec == 0) && (m_start_ts_usec == 0))
            return 0;

#ifdef _WIN32
        typedef union
        {
            unsigned __int64 ft_scalar;
            FILETIME ft_struct;
        } FT;

        FT nt_time;
        GetSystemTimeAsFileTime(&(nt_time.ft_struct));
        unsigned __int64 usec = (nt_time.ft_scalar - 116444736000000000i64) / 10i64;
        unsigned long ts_sec  = (unsigned long) (usec / 1000000);
        unsigned long ts_usec = (unsigned long) (usec % 1000000);
#else
        timeval tv;
        gettimeofday(&tv,NULL);
        unsigned long ts_sec = tv.tv_sec;
        unsigned long ts_usec = tv.tv_usec;
#endif

        unsigned long result = (ts_sec - m_start_ts_sec) * 1000000 + ts_usec - m_start_ts_usec;

        return result;
    }

private:

    unsigned long m_start_ts_sec;
    unsigned long m_start_ts_usec;
};

//////////////////////////////////////////////////////////////////////////////////
